﻿namespace PerfectPractice.Models
{
    public class CartProductModel
    {
        public int id { get; set; }
        public string ProductName { get; set; }
        public string images { get; set; }
        public double Price { get; set; }
        public string ProductId { get; set; }
    }
}
